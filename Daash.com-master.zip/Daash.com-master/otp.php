<?php
define("API_KEY",'/jlHaRHsK8M-ZF8nBqs50aMvIqV7lXJFvkEOkJmhDH');
define("MOBILE",'');
?>