<?php 
	/*Enter your API_KEY*/
	define("API_KEY", '/jlHaRHsK8M-ZF8nBqs50aMvIqV7lXJFvkEOkJmhDH');

	/*You can enter mobile number here*/
	define("MOBILE", '');
 ?>